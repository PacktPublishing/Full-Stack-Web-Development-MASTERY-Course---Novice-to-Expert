import React from 'react'
const Home = () => {
  return (
    <div className="container">
    
    <h1 className="text-center" style={{paddingTop: "30%"}}>
      Home
    </h1>
    
  </div>
  )
}
export default Home;