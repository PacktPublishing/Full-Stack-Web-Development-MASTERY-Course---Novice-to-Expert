import React from 'react'
const Contact = () => {
  return (
    <div className="container">
    
      <h1 className="text-center" style={{paddingTop: "30%"}}>
        Contact Us
      </h1>
      
    </div>
  )
}
export default Contact;