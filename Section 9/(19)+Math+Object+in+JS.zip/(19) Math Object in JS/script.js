let x = 3;
let y = 6;
let z;

z = x+y;
z = x-y;
z = x*y;
z = x/y;


// Math Object in JavaScript
z = Math;
z = Math.PI;
z = Math.E;
z = Math.round(1.8);
z = Math.ceil(1.3);
z = Math.floor(1.9);
z = Math.abs(-5);
z = Math.sqrt(72);
z = Math.pow(2,3);
z = Math.min(2,3,-51,0,90);
z = Math.max(2,3,-51,0,90);
z = Math.random();
z = 100*Math.random();
z = 50 + (100-50)*Math.random();
z = Math.ceil(50 + (100-50)*Math.random());
console.log(z);