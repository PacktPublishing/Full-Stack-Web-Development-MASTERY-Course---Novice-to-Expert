console.log("Manipulating webpages using JS");

// Window object properties
// let a = document;
// a = window.innerWidth;
// a = innerHeight;
// a = location.toString();
// // scrollX
// // scrollY
// // history.go(-1);
// console.log(a);

// Window Object methods
let b = document;
// window.alert("This is Alert");
// window.prompt("Enter your login ID");
// window.close();
window.confirm("Are you sure you want to continue");