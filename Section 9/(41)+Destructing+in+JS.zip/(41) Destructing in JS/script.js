// const person = {first: 'John', last: 'Anderton', country: 'USA'};
// // const first = person.first;
// // const second = person.second;

// const {first , second} = person;


var colors = ["Red", "Green", "Blue", "Yellow"];
var [a, b, ...c] = colors;
console.log(a);
console.log(b);
console.log(c);