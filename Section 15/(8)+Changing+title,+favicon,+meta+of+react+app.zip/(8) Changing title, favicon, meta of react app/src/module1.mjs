const a = "John";
const b = "Jack";
const c = "Sam";
const d = "Tom";

export default d;
export {a};
export {b};