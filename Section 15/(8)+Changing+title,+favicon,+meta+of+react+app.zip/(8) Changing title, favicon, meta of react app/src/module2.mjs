import xyz from './module1.mjs'
import {a,b} from './module1.mjs'
console.log(xyz);
console.log(a);
console.log(b);