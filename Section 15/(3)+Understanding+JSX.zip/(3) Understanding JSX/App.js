import logo from './logo.svg';
import './App.css';

let name = "Sam";
function App() {
  return (
    <>
      <nav>
        <li>Home</li>
        <li>About</li>
        <li>Contac Us</li>
      </nav>
      <div className="container">
        <p>lorem ewewmfmew wfmwekmw</p>
        <h1>Hey, {name}</h1>
        </div>
    </>
  );
}

export default App;
