import React, { Component } from 'react'

export class NewsItems extends Component {
  render() {
    return (
      <div>NewsItems</div>
    )
  }
}

export default NewsItems