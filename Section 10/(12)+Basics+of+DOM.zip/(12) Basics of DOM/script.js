console.log("DOM");

let a = document;
a = document.all;
a = document.body;
a = document.documentElement;
a = document.head;
a = document.anchors;
a = document.forms;
a = document.links;
a = document.URL;
a = document.title;
a = document.scripts;
console.log(a);